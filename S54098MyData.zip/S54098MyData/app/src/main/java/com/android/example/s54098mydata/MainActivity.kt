package com.android.example.s54098mydata

import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import com.google.android.material.floatingactionbutton.FloatingActionButton
import java.io.File

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)



        var entities = ArrayList<String>()
        if (!dbExists(this, "mydata")){
            createDB();
        }
        val db: SQLiteDatabase = openOrCreateDatabase("mydata", MODE_PRIVATE,null)
        val sql = "SELECT username from user"
        val c: Cursor = db.rawQuery(sql, null)
        while(c.moveToNext()){
            val entiti = c.getString(0)
            entities.add(entiti)
        }
        c.close()

       val myAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1,entities)
        val lv = findViewById<ListView>(R.id.lv)
        lv.setAdapter(myAdapter)
        lv.onItemClickListener = AdapterView.OnItemClickListener{ adapter, v, position, arg3 ->
            val value = adapter.getItemAtPosition(position).toString()
            val intent = Intent(this, SecondActivity::class.java).apply {
                putExtra("entiti", value.toString())
            }
            startActivity(intent)
        }


        val btnSubmit = findViewById<Button>(R.id.btnSubmit)
        btnSubmit.setOnClickListener(){
            val intent = Intent(this, SecondActivity::class.java).apply {

            }
            startActivity(intent)
        }
    }
    //-----------------------------------------------------------------------
    private fun dbExists(c: Context, dbName: String):Boolean{
        val dbFile: File = c.getDatabasePath(dbName)
        return dbFile.exists()
    }

    private fun createDB() {
        val db = openOrCreateDatabase("mydata", MODE_PRIVATE, null)
        subToast("Database mydata created!")
        val sqlText = "CREATE TABLE IF NOT EXISTS user" +
                "(username VARCHAR(30) PRIMARY KEY," +
                "password VARCHAR(30) NOT NULL" +
                ");"

        subToast("Table user created")
        db.execSQL(sqlText)
        var nextSQL = "INSERT INTO user( username,password) VALUES ('ahmad','ahmad1234');"
        db.execSQL(nextSQL)

        subToast("1 sample entities added")




//-------------------------------------------------------------------------------------------------------------
        val btnSubmit =  findViewById<Button>(R.id.btnSubmit)
        btnSubmit.setOnClickListener(){
            val username = findViewById<EditText>(R.id.inUserName)
            val password = findViewById<EditText>(R.id.inPassword)


            val emptyLevel = emptiness(username, password)
            if (emptyLevel>0){
                //which field is empty
                when(emptyLevel){
                    5 -> subToast("username must not empty!")
                    6 -> subToast("password must not empty!")
                    11 -> subToast("username and password must not empty")

                }
            }else{
                //check for exists entity
                val status = checkKey(username.text.toString())
                val un = username.text.toString()
                val pw = password.text.toString()

                if(!status){
                    val db = openOrCreateDatabase("mydata", MODE_PRIVATE,null)
                    val sql = "INSERT INTO user (username, password) VALUES ('$un','$pw');"
                    db.execSQL(sql)
                    subToast("new entiti $un added!")
                    val intent = Intent(this, SecondActivity::class.java).apply {

                    }
                    startActivity(intent)
                }else{
                    subToast("entiti already exists inside database!")
                }
            }

        }

    }

    private fun checkKey(username: String):Boolean{
        val db = openOrCreateDatabase("mydata", MODE_PRIVATE,null)
        val sql = "select * from user where username='$username'"
        val cursor = db.rawQuery(sql, null)
        var out=false
        if(cursor.count>0)
            out=true
        return out
    }
    private fun emptiness(username: EditText, password: EditText):Int{
        var empty = 0

        if(username.text.isEmpty())
            empty+=5

        if(password.text.isEmpty())
            empty+=6

        return empty

    }
    private fun subToast(msg: String){
        Toast.makeText(this,msg, Toast.LENGTH_SHORT).show()


    }}

