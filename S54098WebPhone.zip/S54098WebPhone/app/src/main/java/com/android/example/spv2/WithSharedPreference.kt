package com.android.example.spv2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText

class WithSharedPreference : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_with_shared_preference)

        val actionBar = supportActionBar
        actionBar!!.title = "Web Address"
        actionBar.setDisplayHomeAsUpEnabled(true)

        val sp = this.getSharedPreferences("ahmad", MODE_PRIVATE)

        val iWeb = findViewById<EditText>(R.id.inputWeb)


        iWeb.setText(sp.getString("name", null))

    }

    override fun onPause() {
        super.onPause()
        val iWeb = findViewById<EditText>(R.id.inputWeb)


        val sp = this.getSharedPreferences("ahmad", MODE_PRIVATE)
        val editor = sp.edit()
        editor.putString("name", iWeb.text.toString())

        editor.commit()
    }
}