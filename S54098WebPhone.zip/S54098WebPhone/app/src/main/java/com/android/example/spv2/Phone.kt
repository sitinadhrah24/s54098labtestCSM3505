package com.android.example.spv2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText

class Phone : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_phone)

        val actionBar = supportActionBar
        actionBar!!.title = "Phone Number"
        actionBar.setDisplayHomeAsUpEnabled(true)

        val sp = this.getSharedPreferences("ahmad", MODE_PRIVATE)


        val iph = findViewById<EditText>(R.id.inputPhone)


        iph.setText(sp.getString("phone", null))
    }

    override fun onPause() {
        super.onPause()

        val ip = findViewById<EditText>(R.id.inputPhone)

        val sp = this.getSharedPreferences("ahmad", MODE_PRIVATE)
        val editor = sp.edit()
        editor.putString("phone", ip.text.toString())
        editor.commit()
    }
}