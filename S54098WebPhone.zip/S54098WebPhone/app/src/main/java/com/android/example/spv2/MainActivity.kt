package com.android.example.spv2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun GotoSecondActivity(view: View){
        val intent = Intent(this, WithSharedPreference::class.java).apply{

        }
        startActivity(intent)
    }
    fun goToPhoneAct(view: View){
        val intent = Intent(this, Phone::class.java).apply{

        }
        startActivity(intent)
    }
}